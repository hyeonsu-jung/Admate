export default function MinimalPage() {
  return (
    <html>
      <head>
        <title>Minimal Test</title>
      </head>
      <body>
        <h1>Minimal Test Page</h1>
        <p>This is a minimal test page.</p>
      </body>
    </html>
  );
}
